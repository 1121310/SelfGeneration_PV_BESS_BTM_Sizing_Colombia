# Entrega Proyecto II — Mapas de LCOE PV+BESS Colombia

## Contenido de esta entrega

- **`informe_latex/`** — Proyecto Overleaf completo (subir esta carpeta completa,
  o su contenido, a un proyecto nuevo en Overleaf):
  - `main.tex` — Informe principal (≤10 páginas): Resumen/Abstract, Introducción,
    Marco Teórico, Metodología, Resultados y Análisis, Conclusiones, Uso de IA.
  - `anexos.tex` — Documento de Anexos (≤20 páginas): Anexo A (repositorio/código),
    Anexo B (material complementario: tabla completa de 72 resultados, verificación,
    errores corregidos, fuentes).
  - `secciones/`, `tablas/`, `figuras/`, `codigo/`, `referencias.bib`.
  - `main.pdf`, `anexos.pdf` — versiones ya compiladas (vista previa).

- **`repo_github_pv_bess_colombia/`** — Código fuente completo del proyecto,
  listo para subir a GitHub (ver su `README.md` para instrucciones). Es la misma
  base de código referenciada como Anexo A.

## Pasos para la entrega

1. **Overleaf**: crear un proyecto nuevo → subir el contenido de `informe_latex/`
   → compilar `main.tex` (informe) y `anexos.tex` (anexos) por separado →
   agregar los nombres de los 3 integrantes en `main.tex` y `anexos.tex` →
   cada integrante debe entrar a Overleaf y "firmar" según lo pida el curso.
2. **GitHub**: desde una cuenta del equipo, `git init` en
   `repo_github_pv_bess_colombia/`, hacer commit y `git push` a un repositorio
   nuevo; copiar el enlace público resultante.
3. **Bloque Neón**: subir el PDF del informe, el PDF de anexos, y el enlace al
   repositorio de GitHub, desde la cuenta de cada integrante que deba firmar.

## Nota sobre autoría y uso de IA

Antes de subir, cada integrante debe leer la Sección "Uso de inteligencia
artificial" del informe principal y confirmar que refleja fielmente el alcance
real del apoyo de IA usado por el equipo, ajustándola si es necesario.
